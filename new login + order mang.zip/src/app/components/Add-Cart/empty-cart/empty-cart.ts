import { Component } from '@angular/core';

@Component({
  selector: 'app-empty-cart',
  imports: [],
  templateUrl: './empty-cart.html',
  styleUrl: './empty-cart.css',
})
export class EmptyCart {

}
